
public class UserInput {

    private int userInputY;
    private int userInputX;


    public void userControl(int inputX, int inputY){

        if (inputX <= 1 && inputX >= -1) {
            System.out.println(inputX);
        } if (inputY <= 1 && inputY >= -1){
            System.out.println(inputY);
        }
    }



}
